package com.liting.cs504.runninginformationanalysistwoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunningInformationAnalysisTwoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunningInformationAnalysisTwoServiceApplication.class, args);
	}
}
